// lib/main.dart
//
// Punto de entrada.
// Orden de inicialización:
//   1. AppState (carga clientes guardados)
//   2. DeepLinkService (escucha intents, inyecta en AppState)
//   3. MaterialApp con Provider
//
// El DeepLinkService guarda referencia a AppState.
// Cuando llega un link, llama state.injectDeepLink(payload).
// HomeScreen escucha state.pendingPayload y abre el sheet.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/app_state.dart';
import 'services/deep_link_service.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final appState = AppState();
  await appState.init();

  final deepLinkService = DeepLinkService(appState);
  await deepLinkService.init();

  runApp(
    ChangeNotifierProvider.value(
      value: appState,
      child: const RouteOptimizerApp(),
    ),
  );
}

class RouteOptimizerApp extends StatelessWidget {
  const RouteOptimizerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Route Optimizer',
      debugShowCheckedModeBanner: false,
      theme: _buildTheme(),
      home: const HomeScreen(),
    );
  }

  ThemeData _buildTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF0D1017),
      colorScheme: const ColorScheme.dark(
        primary:    Color(0xFF00C896),
        secondary:  Color(0xFF58A6FF),
        surface:    Color(0xFF161A27),
        error:      Color(0xFFFF4757),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF0D1017),
        elevation: 0,
        iconTheme: IconThemeData(color: Color(0xFF5C6278)),
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: Color(0xFF161A27),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: Color(0xFF00C896),
        foregroundColor: Colors.black,
      ),
    );
  }
}
