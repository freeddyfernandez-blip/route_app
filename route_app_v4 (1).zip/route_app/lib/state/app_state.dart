// lib/state/app_state.dart — v4
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/client.dart';

String _newId() =>
    DateTime.now().microsecondsSinceEpoch.toRadixString(36) +
    (DateTime.now().hashCode.abs() % 9999).toString();

class AppState extends ChangeNotifier {
  // ── Clientes ─────────────────────────────────────────────────────────────────
  List<Client> _clients = [];
  List<Client> get clients => List.unmodifiable(_clients);

  // ── Modo de viaje ─────────────────────────────────────────────────────────────
  TravelMode _travelMode = TravelMode.car;
  TravelMode get travelMode => _travelMode;

  void setTravelMode(TravelMode mode) {
    if (_travelMode == mode) return;
    _travelMode = mode;
    notifyListeners();
    _savePrefs();
  }

  // ── Cliente activo ────────────────────────────────────────────────────────────
  String? _activeClientId;
  String? get activeClientId => _activeClientId;

  // ── Deep link ─────────────────────────────────────────────────────────────────
  DeepLinkPayload? _pendingPayload;
  DeepLinkPayload? get pendingPayload => _pendingPayload;

  void injectDeepLink(DeepLinkPayload payload) {
    _pendingPayload = payload;
    notifyListeners();
  }

  void consumePayload() {
    _pendingPayload = null;
  }

  // ── Animación entrada ─────────────────────────────────────────────────────────
  String? lastAddedId;

  // ── Init ──────────────────────────────────────────────────────────────────────
  Future<void> init() async {
    await _load();
  }

  // ── Getters computados ────────────────────────────────────────────────────────
  int get totalCount     => _clients.length;
  int get completedCount => _clients.where((c) => c.status.isDone).length;
  int get pendingCount   => _clients.where((c) => c.status.isPending).length;
  // riskCount: placeholder para lógica futura de ventanas horarias
  int get riskCount      => _clients.where((c) =>
      c.status == StopStatus.risk || c.status == StopStatus.late).length;

  // ── CRUD ──────────────────────────────────────────────────────────────────────
  Future<void> addClient(Client client) async {
    final id = client.id.isEmpty ? _newId() : client.id;
    final newClient = client.copyWith(
      id: id,
      order: 0,
      status: StopStatus.pending,
    );
    final rest = [
      for (int i = 0; i < _clients.length; i++)
        _clients[i].copyWith(order: i + 1),
    ];
    _clients = [newClient, ...rest];
    lastAddedId = id;

    // Si no hay activo todavía, este pasa a activo automáticamente
    if (_activeClientId == null) {
      _setActiveInternal(id);
    }

    notifyListeners();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      lastAddedId = null;
    });
    await _saveClients();
  }

  Future<void> updateClient(Client updated) async {
    _clients = [
      for (final c in _clients)
        if (c.id == updated.id) updated else c,
    ];
    notifyListeners();
    await _saveClients();
  }

  Future<void> deleteClient(String id) async {
    _clients = _clients.where((c) => c.id != id).toList();
    if (_activeClientId == id) {
      _activeClientId = null;
      _autoSelectNext();
    }
    _reindex();
    notifyListeners();
    await _saveClients();
  }

  Future<void> reorder(int oldIndex, int newIndex) async {
    if (oldIndex == newIndex) return;
    if (_clients[oldIndex].pinned) return;
    final list = [..._clients];
    final item = list.removeAt(oldIndex);
    final adjusted = newIndex > oldIndex ? newIndex - 1 : newIndex;
    list.insert(adjusted, item);
    _clients = list;
    _reindex();
    notifyListeners();
    await _saveClients();
  }

  Future<void> togglePin(String id) async {
    _clients = [
      for (final c in _clients)
        if (c.id == id) c.copyWith(pinned: !c.pinned) else c,
    ];
    notifyListeners();
    await _saveClients();
  }

  Future<void> clearAll() async {
    _clients = [];
    _activeClientId = null;
    notifyListeners();
    await _saveClients();
  }

  // ── setActive ─────────────────────────────────────────────────────────────────
  // Marca un cliente como activo, los demás pending quedan pending.
  // Los completed NO se tocan.
  Future<void> setActive(String id) async {
    _setActiveInternal(id);
    notifyListeners();
    await _saveClients();
  }

  void _setActiveInternal(String id) {
    _activeClientId = id;
    _clients = [
      for (final c in _clients)
        if (c.id == id)
          c.copyWith(status: StopStatus.active)
        else if (c.status == StopStatus.active)
          c.copyWith(status: StopStatus.pending)
        else
          c,
    ];
  }

  // ── completeClient ────────────────────────────────────────────────────────────
  // 1. Marca el cliente como completed
  // 2. Lo mueve al final (después de otros completed)
  // 3. Selecciona automáticamente el siguiente pending
  Future<void> completeClient(String id) async {
    // Marcar como completed
    _clients = [
      for (final c in _clients)
        if (c.id == id)
          c.copyWith(status: StopStatus.completed)
        else
          c,
    ];

    // Mover completed al final: pending/active primero, completed después
    final pending   = _clients.where((c) => !c.status.isDone).toList();
    final completed = _clients.where((c) => c.status.isDone).toList();
    _clients = [...pending, ...completed];
    _reindex();

    // Limpiar activo si era este
    if (_activeClientId == id) {
      _activeClientId = null;
    }

    // Seleccionar siguiente
    _autoSelectNext();

    notifyListeners();
    await _saveClients();
  }

  // Selecciona el primer pending como activo
  void _autoSelectNext() {
    final next = _clients.where((c) => c.status.isPending).firstOrNull;
    if (next != null) {
      _setActiveInternal(next.id);
    } else {
      _activeClientId = null;
    }
  }

  void _reindex() {
    _clients = [
      for (int i = 0; i < _clients.length; i++)
        _clients[i].copyWith(order: i),
    ];
  }

  // ── Persistencia ──────────────────────────────────────────────────────────────
  static const _keyClients = 'clients_v1';
  static const _keyPrefs   = 'app_prefs_v1';

  Future<void> _saveClients() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _keyClients, jsonEncode(_clients.map((c) => c.toJson()).toList()));
  }

  Future<void> _savePrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _keyPrefs, jsonEncode({'travelMode': _travelMode.index}));
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final raw = prefs.getString(_keyClients);
      if (raw != null) {
        final list = jsonDecode(raw) as List;
        _clients = list
            .map((e) => Client.fromJson(e as Map<String, dynamic>))
            .toList()
          ..sort((a, b) => a.order.compareTo(b.order));
        // Restaurar activo
        final active = _clients.where((c) => c.status.isActive).firstOrNull;
        _activeClientId = active?.id;
        // Si no hay activo, auto-seleccionar
        if (_activeClientId == null && _clients.any((c) => c.status.isPending)) {
          _autoSelectNext();
        }
      }

      final rawPrefs = prefs.getString(_keyPrefs);
      if (rawPrefs != null) {
        final map = jsonDecode(rawPrefs) as Map<String, dynamic>;
        final idx = map['travelMode'] as int? ?? 0;
        _travelMode = TravelMode.values[idx.clamp(0, TravelMode.values.length - 1)];
      }

      notifyListeners();
    } catch (e) {
      debugPrint('AppState._load error: $e');
    }
  }
}
