// lib/services/deep_link_service.dart
//
// Capa de integración entre DeepLinkHandler y AppState.
// Se inicializa una vez en main() y escucha el stream del handler.
// Cuando llega una ubicación válida, la inyecta en AppState.

import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:app_links/app_links.dart';
import 'package:http/http.dart' as http;
import '../models/client.dart';
import '../state/app_state.dart';

// ─── Tipos ────────────────────────────────────────────────────────────────────

enum UriKind { geo, googleMaps, shortLink, unknown }

class _Coords {
  final double lat, lng;
  final String? label;
  final String strategy;
  const _Coords(this.lat, this.lng, {this.label, required this.strategy});
}

// ─── Servicio ─────────────────────────────────────────────────────────────────

class DeepLinkService {
  final AppState _state;
  final _appLinks = AppLinks();

  // Para deduplicar — app_links puede emitir el mismo URI dos veces
  Uri? _lastUri;
  DateTime? _lastUriAt;

  DeepLinkService(this._state);

  Future<void> init() async {
    _log('══ DeepLinkService init ══');

    // COLD START
    try {
      final initial = await _appLinks.getInitialLink();
      if (initial != null) {
        _log('📲 cold start: $initial');
        await _handle(initial);
      }
    } catch (e) {
      _log('❌ getInitialLink: $e');
    }

    // WARM START
    _appLinks.uriLinkStream.listen(
      (uri) async {
        _log('📲 warm start: $uri');
        await _handle(uri);
      },
      onError: (e) => _log('❌ stream: $e'),
      cancelOnError: false,
    );
  }

  // ── Dispatcher ──────────────────────────────────────────────────────────────

  Future<void> _handle(Uri uri) async {
    // Deduplicar
    final now = DateTime.now();
    if (uri == _lastUri &&
        _lastUriAt != null &&
        now.difference(_lastUriAt!).inSeconds < 3) {
      _log('⚠️  duplicado ignorado');
      return;
    }
    _lastUri = uri;
    _lastUriAt = now;

    _log('─── procesando: $uri');
    _log('    scheme=${uri.scheme} host=${uri.host}');

    _Coords? coords;

    try {
      if (uri.scheme == 'geo') {
        coords = _parseGeo(uri);
      } else if (_isShortLink(uri)) {
        coords = await _resolveShortLink(uri);
      } else if (_isGoogleMaps(uri)) {
        coords = _parseGoogleMaps(uri);
      } else {
        _log('⚠️  URI no reconocida');
        return;
      }
    } catch (e, st) {
      _log('❌ excepción inesperada: $e\n$st');
      return;
    }

    if (coords == null) {
      _log('❌ no se encontraron coordenadas');
      return;
    }

    _log('✅ coords: ${coords.lat}, ${coords.lng} [${coords.strategy}]');

    // Inyectar en AppState — esto dispara el sheet en la UI
    _state.injectDeepLink(DeepLinkPayload(
      lat: coords.lat,
      lng: coords.lng,
      suggestedName: coords.label,
      rawUri: uri.toString(),
    ));
  }

  // ── Parser geo: ────────────────────────────────────────────────────────────
  //
  // geo:-34.6037,-58.3816
  // geo:-34.6037,-58.3816,15z
  // geo:0,0?q=-34.6037,-58.3816
  // geo:0,0?q=-34.6037,-58.3816(Nombre)
  // geo:0,0?q=Dirección textual       → null

  _Coords? _parseGeo(Uri uri) {
    final path   = uri.path;
    final qParam = uri.queryParameters['q'];

    _log('  geo path="$path" q="$qParam"');

    // Prioridad: ?q=
    if (qParam != null && qParam.isNotEmpty) {
      String? label;
      String coordStr = qParam;

      final labelMatch = RegExp(r'\(([^)]+)\)\s*$').firstMatch(qParam);
      if (labelMatch != null) {
        label = _decode(labelMatch.group(1)!);
        coordStr = qParam.substring(0, labelMatch.start).trim();
        _log('  label: "$label"');
      }

      final c = _coords(coordStr, src: 'geo ?q');
      if (c != null) return _Coords(c[0], c[1], label: label, strategy: 'geo_q');
      _log('  ?q sin coordenadas (dirección textual?)');
    }

    // Fallback: path
    final clean = path.replaceAll(RegExp(r',\s*\d+\.?\d*z\s*$'), '');
    final parts = clean.split(',');
    if (parts.length >= 2) {
      final lat = double.tryParse(parts[0].trim());
      final lng = double.tryParse(parts[1].trim());
      if (lat != null && lng != null && _valid(lat, lng)) {
        return _Coords(lat, lng, strategy: 'geo_path');
      }
      if (lat == 0.0 && lng == 0.0) _log('  path es (0,0) placeholder');
    }

    return null;
  }

  // ── Parser Google Maps ──────────────────────────────────────────────────────

  _Coords? _parseGoogleMaps(Uri uri) {
    final str = uri.toString();

    // 1. ?q=
    final q = uri.queryParameters['q'];
    if (q != null) {
      final c = _coords(q, src: 'gmaps ?q');
      if (c != null) return _Coords(c[0], c[1],
          label: _placeName(str), strategy: 'gmaps_q');
    }

    // 2. ?ll=
    final ll = uri.queryParameters['ll'];
    if (ll != null) {
      final c = _coords(ll, src: 'gmaps ?ll');
      if (c != null) return _Coords(c[0], c[1],
          label: _placeName(str), strategy: 'gmaps_ll');
    }

    // 3. @lat,lng
    final atM = RegExp(r'@(-?\d{1,2}\.\d{4,}),(-?\d{1,3}\.\d{4,})').firstMatch(str);
    if (atM != null) {
      final lat = double.tryParse(atM.group(1)!);
      final lng = double.tryParse(atM.group(2)!);
      if (lat != null && lng != null && _valid(lat, lng)) {
        return _Coords(lat, lng, label: _placeName(str), strategy: 'gmaps_at');
      }
    }

    // 4. !3d{lat}!4d{lng}
    final latM = RegExp(r'!3d(-?\d+\.\d+)').firstMatch(str);
    final lngM = RegExp(r'!4d(-?\d+\.\d+)').firstMatch(str);
    if (latM != null && lngM != null) {
      final lat = double.tryParse(latM.group(1)!);
      final lng = double.tryParse(lngM.group(1)!);
      if (lat != null && lng != null && _valid(lat, lng)) {
        return _Coords(lat, lng, label: _placeName(str), strategy: 'gmaps_data');
      }
    }

    // 5. Regex libre
    final c = _coords(str, src: 'gmaps free');
    if (c != null) return _Coords(c[0], c[1],
        label: _placeName(str), strategy: 'gmaps_free');

    return null;
  }

  // ── Resolver short links ────────────────────────────────────────────────────

  static const _maxHops = 6;
  static const _timeout = Duration(seconds: 10);
  static const _ua =
      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

  Future<_Coords?> _resolveShortLink(Uri origin) async {
    Uri current = origin;
    for (int hop = 1; hop <= _maxHops; hop++) {
      _log('  [hop $hop] GET $current');
      http.Response res;
      try {
        res = await http
            .get(current, headers: {'User-Agent': _ua})
            .timeout(_timeout);
      } on SocketException catch (e) {
        _log('  ❌ sin red: $e'); return null;
      } on TimeoutException {
        _log('  ❌ timeout');    return null;
      } catch (e) {
        _log('  ❌ http: $e');   return null;
      }

      _log('  [hop $hop] HTTP ${res.statusCode}');

      if (res.statusCode >= 300 && res.statusCode < 400) {
        final loc = res.headers['location'];
        if (loc == null || loc.isEmpty) break;
        try {
          var next = Uri.parse(loc);
          if (!next.hasScheme) next = current.resolve(loc);
          _log('  → $next');
          current = next;
          continue;
        } catch (e) { _log('  ❌ location inválida: $e'); break; }
      }

      final finalUrl = res.request?.url.toString() ?? current.toString();
      _log('  URL final: $finalUrl');

      final finalUri = Uri.tryParse(finalUrl);
      if (finalUri != null && _isGoogleMaps(finalUri)) {
        final r = _parseGoogleMaps(finalUri);
        if (r != null) return _Coords(r.lat, r.lng,
            label: r.label,
            strategy: 'short→${r.strategy}');
      }

      // Buscar coords en HTML
      final c = _coordsFromHtml(res.body);
      if (c != null) return _Coords(c[0], c[1],
          label: _titleFromHtml(res.body), strategy: 'short_html');
      return null;
    }
    _log('  ❌ límite de $_maxHops hops');
    return null;
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────

  List<double>? _coords(String input, {required String src}) {
    if (input.isEmpty) return null;
    String s;
    try { s = Uri.decodeComponent(input.replaceAll('+', ' ')); }
    catch (_) { s = input; }

    final re = RegExp(r'(-?\d{1,3}\.\d{4,})\s*,\s*(-?\d{1,3}\.\d{4,})');
    for (final m in re.allMatches(s)) {
      final lat = double.tryParse(m.group(1)!);
      final lng = double.tryParse(m.group(2)!);
      if (lat != null && lng != null && _valid(lat, lng)) return [lat, lng];
    }
    return null;
  }

  List<double>? _coordsFromHtml(String html) {
    final og = RegExp(r'center=(-?\d+\.\d+),(-?\d+\.\d+)').firstMatch(html);
    if (og != null) {
      final lat = double.tryParse(og.group(1)!);
      final lng = double.tryParse(og.group(2)!);
      if (lat != null && lng != null && _valid(lat, lng)) return [lat, lng];
    }
    return _coords(html.substring(0, html.length.clamp(0, 5000)), src: 'html');
  }

  bool _valid(double lat, double lng) =>
      lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 &&
      !(lat == 0 && lng == 0);

  bool _isShortLink(Uri u) =>
      u.host == 'maps.app.goo.gl' ||
      (u.host == 'goo.gl' && u.path.startsWith('/maps'));

  bool _isGoogleMaps(Uri u) =>
      u.host == 'maps.google.com' ||
      (u.host == 'www.google.com' && u.path.startsWith('/maps')) ||
      (u.host == 'google.com'     && u.path.startsWith('/maps'));

  String? _placeName(String url) {
    final m = RegExp(r'/place/([^/@?&#]+)').firstMatch(url);
    if (m == null) return null;
    try { return Uri.decodeComponent(m.group(1)!.replaceAll('+', ' ')).trim(); }
    catch (_) { return null; }
  }

  String? _titleFromHtml(String html) {
    final m = RegExp(r'<title[^>]*>([^<]+)</title>').firstMatch(html);
    return m?.group(1)?.trim();
  }

  String _decode(String s) {
    try { return Uri.decodeComponent(s.replaceAll('+', ' ')).trim(); }
    catch (_) { return s.trim(); }
  }

  void _log(String msg) => debugPrint('🔗 $msg');
}
