// lib/models/client.dart
import 'dart:convert';

enum Priority { high, medium, low }

// Ciclo de vida de una parada en la jornada
enum StopStatus {
  pending,    // pendiente (default)
  active,     // en curso (seleccionada actualmente)
  completed,  // completada
  // Alias de compatibilidad con lógica de riesgo futura
  ok, risk, late;

  bool get isDone    => this == completed;
  bool get isActive  => this == active;
  bool get isPending => this == pending;
}

class Client {
  final String id;
  final String name;
  final double lat;
  final double lng;
  final String? address;
  final Priority priority;
  final int serviceMinutes;
  final String? windowStart;
  final String? windowEnd;
  final String? notes;
  final bool pinned;
  final int order;
  final StopStatus status;
  final String? eta;
  final String? warning;

  const Client({
    required this.id,
    required this.name,
    required this.lat,
    required this.lng,
    this.address,
    this.priority = Priority.medium,
    this.serviceMinutes = 10,
    this.windowStart,
    this.windowEnd,
    this.notes,
    this.pinned = false,
    this.order = 0,
    this.status = StopStatus.pending,
    this.eta,
    this.warning,
  });

  Client copyWith({
    String? id,
    String? name,
    double? lat,
    double? lng,
    String? address,
    Priority? priority,
    int? serviceMinutes,
    String? windowStart,
    String? windowEnd,
    String? notes,
    bool? pinned,
    int? order,
    StopStatus? status,
    String? eta,
    String? warning,
  }) => Client(
    id: id ?? this.id,
    name: name ?? this.name,
    lat: lat ?? this.lat,
    lng: lng ?? this.lng,
    address: address ?? this.address,
    priority: priority ?? this.priority,
    serviceMinutes: serviceMinutes ?? this.serviceMinutes,
    windowStart: windowStart ?? this.windowStart,
    windowEnd: windowEnd ?? this.windowEnd,
    notes: notes ?? this.notes,
    pinned: pinned ?? this.pinned,
    order: order ?? this.order,
    status: status ?? this.status,
    eta: eta ?? this.eta,
    warning: warning ?? this.warning,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'lat': lat, 'lng': lng,
    'address': address,
    'priority': priority.index,
    'serviceMinutes': serviceMinutes,
    'windowStart': windowStart,
    'windowEnd': windowEnd,
    'notes': notes,
    'pinned': pinned,
    'order': order,
    'status': status.index,
  };

  factory Client.fromJson(Map<String, dynamic> j) => Client(
    id: j['id'] as String,
    name: j['name'] as String,
    lat: (j['lat'] as num).toDouble(),
    lng: (j['lng'] as num).toDouble(),
    address: j['address'] as String?,
    priority: Priority.values[j['priority'] as int? ?? 1],
    serviceMinutes: j['serviceMinutes'] as int? ?? 10,
    windowStart: j['windowStart'] as String?,
    windowEnd: j['windowEnd'] as String?,
    notes: j['notes'] as String?,
    pinned: j['pinned'] as bool? ?? false,
    order: j['order'] as int? ?? 0,
    // Leer status con fallback a pending (compatibilidad con datos viejos)
    status: _statusFromIndex(j['status'] as int?),
  );

  static StopStatus _statusFromIndex(int? idx) {
    if (idx == null) return StopStatus.pending;
    if (idx < 0 || idx >= StopStatus.values.length) return StopStatus.pending;
    return StopStatus.values[idx];
  }

  String get priorityLabel => switch (priority) {
    Priority.high   => 'ALTA',
    Priority.medium => 'MEDIA',
    Priority.low    => 'BAJA',
  };
}

// ── Deep link payload ─────────────────────────────────────────────────────────
class DeepLinkPayload {
  final double lat;
  final double lng;
  final String? suggestedName;
  final String rawUri;

  const DeepLinkPayload({
    required this.lat,
    required this.lng,
    this.suggestedName,
    required this.rawUri,
  });
}

// ── Modo de viaje ─────────────────────────────────────────────────────────────
enum TravelMode { car, moto, walk }

extension TravelModeX on TravelMode {
  String get emoji => const {'car': '🚗', 'moto': '🏍️', 'walk': '🚶'}[name]!;
  String get label => const {'car': 'Auto', 'moto': 'Moto', 'walk': 'A pie'}[name]!;
  double get avgKmh => switch (this) {
    TravelMode.car  => 35,
    TravelMode.moto => 40,
    TravelMode.walk => 5,
  };
  String get gmapsMode => switch (this) {
    TravelMode.car  => 'd',
    TravelMode.moto => 'd',
    TravelMode.walk => 'w',
  };
}
