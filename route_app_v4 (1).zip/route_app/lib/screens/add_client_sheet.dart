// lib/screens/add_client_sheet.dart
//
// Mejoras UX v2:
//   - Modal se abre instantáneamente; procesamiento no bloquea
//   - Coordenadas mostradas como etiqueta legible, no lat/lng crudos
//   - Haptic feedback al guardar
//   - Animación de confirmación antes de cerrar
//   - Campo nombre auto-enfocado desde deep link
//   - Valores por defecto razonables (10min servicio, prioridad media)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/client.dart';
import '../state/app_state.dart';

class AddClientSheet extends StatefulWidget {
  final DeepLinkPayload? payload;
  final Client? editing;

  const AddClientSheet({super.key, this.payload, this.editing});

  static Future<Client?> show(
    BuildContext context, {
    DeepLinkPayload? payload,
    Client? editing,
  }) {
    return showModalBottomSheet<Client>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      enableDrag: true,
      useSafeArea: true,
      builder: (_) => AddClientSheet(payload: payload, editing: editing),
    );
  }

  @override
  State<AddClientSheet> createState() => _AddClientSheetState();
}

class _AddClientSheetState extends State<AddClientSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _lat;
  late final TextEditingController _lng;
  late final TextEditingController _service;
  late final TextEditingController _notes;
  final _nameFocus = FocusNode();

  late Priority _priority;
  bool _showAdvanced = false;
  bool _saving = false;  // bloquea doble-tap en guardar
  bool _saved  = false;  // dispara animación de confirmación

  bool get _isEditing   => widget.editing != null;
  bool get _fromDeepLink => widget.payload != null;

  // ── Init ────────────────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    final e = widget.editing;
    final p = widget.payload;

    _name    = TextEditingController(text: e?.name ?? p?.suggestedName ?? '');
    _lat     = TextEditingController(
        text: e != null ? e.lat.toStringAsFixed(6)
            : p != null ? p.lat.toStringAsFixed(6) : '');
    _lng     = TextEditingController(
        text: e != null ? e.lng.toStringAsFixed(6)
            : p != null ? p.lng.toStringAsFixed(6) : '');
    _service = TextEditingController(text: (e?.serviceMinutes ?? 10).toString());
    _notes   = TextEditingController(text: e?.notes ?? '');
    _priority = e?.priority ?? Priority.medium;

    // Foco automático en nombre cuando vienen coords ya cargadas
    if (_fromDeepLink || _isEditing) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Future.delayed(180.ms, () {
          if (mounted) _nameFocus.requestFocus();
        });
      });
    }
  }

  @override
  void dispose() {
    _name.dispose(); _lat.dispose(); _lng.dispose();
    _service.dispose(); _notes.dispose(); _nameFocus.dispose();
    super.dispose();
  }

  // ── Build ────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF13161F),
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        border: Border(top: BorderSide(color: Color(0xFF252A3A), width: 1)),
      ),
      padding: EdgeInsets.only(bottom: bottom),
      child: SafeArea(
        top: false,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _Handle(),
                const SizedBox(height: 6),
                _buildHeader(),
                const SizedBox(height: 18),

                // ── Coordenadas como etiqueta (siempre visible, no editable) ──
                if (_hasCoords) ...[
                  _LocationChip(
                    lat: double.tryParse(_lat.text) ?? 0,
                    lng: double.tryParse(_lng.text) ?? 0,
                    fromDeepLink: _fromDeepLink,
                  ),
                  const SizedBox(height: 16),
                ],

                // ── Nombre ──────────────────────────────────────────────────
                _FieldLabel('NOMBRE'),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _name,
                  focusNode: _nameFocus,
                  style: GoogleFonts.barlow(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w600),
                  decoration: _deco('Ej: Farmacia López, Cliente Rodríguez'),
                  textCapitalization: TextCapitalization.words,
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => _save(),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Ingresa un nombre' : null,
                ),

                const SizedBox(height: 16),

                // ── Prioridad ────────────────────────────────────────────────
                _FieldLabel('PRIORIDAD'),
                const SizedBox(height: 8),
                _PrioritySelector(
                  value: _priority,
                  onChanged: (p) => setState(() => _priority = p),
                ),

                const SizedBox(height: 14),

                // ── Avanzado (colapsable) ───────────────────────────────────
                _AdvancedToggle(
                  open: _showAdvanced,
                  onToggle: () => setState(() => _showAdvanced = !_showAdvanced),
                ),

                if (_showAdvanced) ...[
                  const SizedBox(height: 14),
                  _buildAdvanced(),
                ],

                const SizedBox(height: 26),
                _buildActions(),
              ],
            ),
          ),
        ),
      ),
    ).animate().slideY(
      begin: 0.12, end: 0,
      duration: 200.ms,
      curve: Curves.easeOutCubic,
    );
  }

  bool get _hasCoords =>
      _lat.text.isNotEmpty && _lng.text.isNotEmpty;

  // ── Header ───────────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return Row(children: [
      if (_fromDeepLink) ...[
        _WhatsAppBadge(),
        const SizedBox(width: 10),
      ],
      Expanded(
        child: Text(
          _isEditing ? 'Editar parada' : 'Nueva parada',
          style: GoogleFonts.barlow(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.5),
        ),
      ),
    ]);
  }

  // ── Campos avanzados ─────────────────────────────────────────────────────────

  Widget _buildAdvanced() {
    return Column(children: [
      // Coords editables (avanzado — no las mostramos arriba en modo editable
      // para no confundir al usuario en el flujo rápido)
      Row(children: [
        Expanded(child: _CoordField(ctrl: _lat, hint: 'Latitud',  field: 'lat')),
        const SizedBox(width: 8),
        Expanded(child: _CoordField(ctrl: _lng, hint: 'Longitud', field: 'lng')),
      ]),
      const SizedBox(height: 12),
      _FieldLabel('TIEMPO EN PARADA (min)'),
      const SizedBox(height: 6),
      TextFormField(
        controller: _service,
        style: GoogleFonts.ibmPlexMono(color: Colors.white, fontSize: 14),
        decoration: _deco('10'),
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      ),
      const SizedBox(height: 12),
      _FieldLabel('NOTAS'),
      const SizedBox(height: 6),
      TextFormField(
        controller: _notes,
        style: GoogleFonts.ibmPlexMono(color: Colors.white, fontSize: 13),
        decoration: _deco('Instrucciones, referencias...'),
        maxLines: 2,
      ),
    ]).animate().fadeIn(duration: 160.ms).slideY(begin: -0.04, end: 0);
  }

  // ── Acciones ─────────────────────────────────────────────────────────────────

  Widget _buildActions() {
    // Estado "guardado" — muestra checkmark brevemente
    if (_saved) {
      return SizedBox(
        width: double.infinity,
        height: 50,
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF00C896),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.check_rounded, color: Colors.black, size: 22),
            const SizedBox(width: 8),
            Text('Guardado',
                style: GoogleFonts.barlow(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w700)),
          ]),
        ).animate().scale(begin: const Offset(0.95, 0.95), end: const Offset(1, 1),
            duration: 150.ms, curve: Curves.easeOutBack),
      );
    }

    return Row(children: [
      // Cancelar
      Expanded(
        child: TextButton(
          onPressed: () => Navigator.pop(context),
          style: TextButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: const BorderSide(color: Color(0xFF252A3A)),
            ),
          ),
          child: Text('Cancelar',
              style: GoogleFonts.barlow(
                  color: const Color(0xFF5C6278),
                  fontSize: 15,
                  fontWeight: FontWeight.w600)),
        ),
      ),
      const SizedBox(width: 10),
      // Guardar
      Expanded(
        flex: 2,
        child: ElevatedButton(
          onPressed: _saving ? null : _save,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF00C896),
            foregroundColor: Colors.black,
            disabledBackgroundColor: const Color(0xFF00C896).withOpacity(0.5),
            padding: const EdgeInsets.symmetric(vertical: 14),
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
          child: _saving
              ? const SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.black))
              : Text(
                  _isEditing ? 'Guardar cambios' : 'Agregar parada',
                  style: GoogleFonts.barlow(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.2),
                ),
        ),
      ),
    ]);
  }

  // ── Lógica guardar ────────────────────────────────────────────────────────────

  Future<void> _save() async {
    if (_saving) return;
    if (!_formKey.currentState!.validate()) return;

    setState(() => _saving = true);

    // Haptic feedback inmediato
    HapticFeedback.mediumImpact();

    final state = context.read<AppState>();

    // Asegurar coordenadas válidas (puede que el usuario limpió los campos en avanzado)
    final lat = double.tryParse(_lat.text.trim()) ?? 0.0;
    final lng = double.tryParse(_lng.text.trim()) ?? 0.0;

    final client = Client(
      id: widget.editing?.id ?? '',
      name: _name.text.trim(),
      lat: lat,
      lng: lng,
      priority: _priority,
      serviceMinutes: int.tryParse(_service.text.trim()) ?? 10,
      notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      order: widget.editing?.order ?? 0,
    );

    if (_isEditing) {
      await state.updateClient(client);
    } else {
      await state.addClient(client);
    }

    // Mostrar confirmación visual brevemente, luego cerrar
    if (mounted) {
      setState(() { _saving = false; _saved = true; });
      HapticFeedback.lightImpact(); // segundo feedback = confirmación
      await Future.delayed(600.ms);
      if (mounted) Navigator.pop(context, client);
    }
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────

  InputDecoration _deco(String hint) => InputDecoration(
    hintText: hint,
    hintStyle: GoogleFonts.ibmPlexMono(
        color: const Color(0xFF35394A), fontSize: 13),
    filled: true,
    fillColor: const Color(0xFF0D1017),
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
    border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xFF252A3A))),
    enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xFF252A3A))),
    focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xFF00C896), width: 1.5)),
    errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xFFFF4757))),
    errorStyle: GoogleFonts.ibmPlexMono(
        fontSize: 10, color: const Color(0xFFFF4757)),
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Sub-widgets
// ═══════════════════════════════════════════════════════════════════════════════

class _Handle extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
    child: Container(
      width: 40, height: 4,
      decoration: BoxDecoration(
        color: const Color(0xFF252A3A),
        borderRadius: BorderRadius.circular(2),
      ),
    ),
  );
}

class _WhatsAppBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0xFF25D366).withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.3)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.link_rounded, color: Color(0xFF25D366), size: 11),
        const SizedBox(width: 4),
        Text('WhatsApp',
            style: GoogleFonts.ibmPlexMono(
                color: const Color(0xFF25D366), fontSize: 10,
                fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

/// Muestra las coordenadas de forma legible, no como números crudos.
/// Formato: "12°34'56" S, 58°22'44" O"  con fallback a decimales cortos.
class _LocationChip extends StatelessWidget {
  final double lat, lng;
  final bool fromDeepLink;

  const _LocationChip({
    required this.lat, required this.lng, required this.fromDeepLink,
  });

  String _dms(double deg, bool isLat) {
    final abs    = deg.abs();
    final d      = abs.truncate();
    final mFull  = (abs - d) * 60;
    final m      = mFull.truncate();
    final s      = ((mFull - m) * 60).truncate();
    final dir    = isLat ? (deg >= 0 ? 'N' : 'S') : (deg >= 0 ? 'E' : 'O');
    return '$d°${m.toString().padLeft(2,'0')}\'${s.toString().padLeft(2,'0')}" $dir';
  }

  @override
  Widget build(BuildContext context) {
    final latStr = _dms(lat, true);
    final lngStr = _dms(lng, false);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1017),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: fromDeepLink
              ? const Color(0xFF25D366).withOpacity(0.2)
              : const Color(0xFF252A3A),
        ),
      ),
      child: Row(children: [
        Icon(
          fromDeepLink ? Icons.my_location_rounded : Icons.location_on_outlined,
          color: fromDeepLink
              ? const Color(0xFF25D366)
              : const Color(0xFF5C6278),
          size: 16,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              latStr,
              style: GoogleFonts.ibmPlexMono(
                  color: const Color(0xFFB0B8CC), fontSize: 12,
                  fontWeight: FontWeight.w500),
            ),
            Text(
              lngStr,
              style: GoogleFonts.ibmPlexMono(
                  color: const Color(0xFFB0B8CC), fontSize: 12,
                  fontWeight: FontWeight.w500),
            ),
          ]),
        ),
        // Copia rápida al portapapeles
        GestureDetector(
          onTap: () {
            Clipboard.setData(ClipboardData(
                text: '${lat.toStringAsFixed(6)},${lng.toStringAsFixed(6)}'));
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Coordenadas copiadas',
                    style: GoogleFonts.ibmPlexMono(fontSize: 12)),
                backgroundColor: const Color(0xFF161A27),
                duration: const Duration(seconds: 1),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: Icon(Icons.copy_rounded,
                size: 14, color: const Color(0xFF3A3E52)),
          ),
        ),
      ]),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);
  @override
  Widget build(BuildContext context) => Text(
    text,
    style: GoogleFonts.ibmPlexMono(
        color: const Color(0xFF5C6278),
        fontSize: 10, letterSpacing: 1.4),
  );
}

class _PrioritySelector extends StatelessWidget {
  final Priority value;
  final ValueChanged<Priority> onChanged;

  const _PrioritySelector({required this.value, required this.onChanged});

  static const _options = [
    (Priority.high,   'ALTA',  Color(0xFFFF4757)),
    (Priority.medium, 'MEDIA', Color(0xFFFFA500)),
    (Priority.low,    'BAJA',  Color(0xFF00C896)),
  ];

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      for (final opt in _options) ...[
        Expanded(
          child: GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              onChanged(opt.$1);
            },
            child: AnimatedContainer(
              duration: 120.ms,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: value == opt.$1
                    ? opt.$3.withOpacity(0.13)
                    : const Color(0xFF0D1017),
                borderRadius: BorderRadius.circular(9),
                border: Border.all(
                  color: value == opt.$1
                      ? opt.$3.withOpacity(0.6)
                      : const Color(0xFF252A3A),
                  width: value == opt.$1 ? 1.5 : 1,
                ),
              ),
              child: Center(
                child: Text(opt.$2,
                    style: GoogleFonts.ibmPlexMono(
                      color: value == opt.$1
                          ? opt.$3
                          : const Color(0xFF3A3E52),
                      fontSize: 11,
                      fontWeight: value == opt.$1
                          ? FontWeight.w700
                          : FontWeight.normal,
                      letterSpacing: 0.5,
                    )),
              ),
            ),
          ),
        ),
        if (opt.$1 != Priority.low) const SizedBox(width: 8),
      ],
    ]);
  }
}

class _AdvancedToggle extends StatelessWidget {
  final bool open;
  final VoidCallback onToggle;
  const _AdvancedToggle({required this.open, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onToggle,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(children: [
          AnimatedRotation(
            turns: open ? 0.5 : 0,
            duration: 160.ms,
            child: const Icon(Icons.expand_more,
                color: Color(0xFF3A3E52), size: 18),
          ),
          const SizedBox(width: 4),
          Text(
            open ? 'Menos opciones' : 'Tiempo de servicio, notas y coordenadas',
            style: GoogleFonts.ibmPlexMono(
                color: const Color(0xFF3A3E52), fontSize: 11),
          ),
        ]),
      ),
    );
  }
}

class _CoordField extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint, field;
  const _CoordField({required this.ctrl, required this.hint, required this.field});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: ctrl,
      style: GoogleFonts.ibmPlexMono(
          color: const Color(0xFF7FFFFF), fontSize: 12),
      keyboardType: const TextInputType.numberWithOptions(
          decimal: true, signed: true),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: GoogleFonts.ibmPlexMono(
            color: const Color(0xFF35394A), fontSize: 11),
        filled: true,
        fillColor: const Color(0xFF0D1017),
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Color(0xFF252A3A))),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Color(0xFF1A2040))),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(
                color: Color(0xFF7FFFFF), width: 1.5)),
        errorStyle: GoogleFonts.ibmPlexMono(
            fontSize: 9, color: const Color(0xFFFF4757)),
      ),
      validator: (v) {
        if (v == null || v.trim().isEmpty) return 'Requerido';
        final n = double.tryParse(v.trim());
        if (n == null) return 'Inválido';
        if (field == 'lat' && (n < -90  || n > 90))  return '-90 a 90';
        if (field == 'lng' && (n < -180 || n > 180)) return '-180 a 180';
        return null;
      },
    );
  }
}
