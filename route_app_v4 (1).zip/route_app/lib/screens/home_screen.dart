// lib/screens/home_screen.dart — v4
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../state/app_state.dart';
import '../models/client.dart';
import '../widgets/stop_card.dart';
import 'add_client_sheet.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _sheetOpen = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkPayload());
  }

  void _checkPayload() {
    if (_sheetOpen || !mounted) return;
    final state = context.read<AppState>();
    final payload = state.pendingPayload;
    if (payload == null) return;
    state.consumePayload();
    _openSheet(payload: payload);
  }

  Future<void> _openSheet({DeepLinkPayload? payload, Client? editing}) async {
    _sheetOpen = true;
    await AddClientSheet.show(context, payload: payload, editing: editing);
    _sheetOpen = false;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(builder: (context, state, _) {
      if (state.pendingPayload != null && !_sheetOpen) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _checkPayload());
      }

      return Scaffold(
        backgroundColor: const Color(0xFF0D1017),
        body: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            _AppBar(state: state, onClear: () => _confirmClear(state)),
            _ContextHeader(state: state),
            if (state.clients.isEmpty)
              _EmptySliver(onAdd: () => _openSheet())
            else
              _ClientList(
                clients: state.clients,
                lastAddedId: state.lastAddedId,
                onReorder: state.reorder,
                onEdit: (c) => _openSheet(editing: c),
                onDelete: (c) => _confirmDelete(state, c),
                onPin: state.togglePin,
              ),
          ],
        ),
        floatingActionButton: _FAB(
          isEmpty: state.clients.isEmpty,
          onTap: () => _openSheet(),
        ),
        bottomNavigationBar: state.clients.isNotEmpty
            ? _BottomBar(state: state)
            : null,
      );
    });
  }

  Future<void> _confirmClear(AppState state) async {
    if (state.clients.isEmpty) return;
    final ok = await _Confirm.show(context,
        title: '¿Limpiar todo?',
        body: 'Se eliminarán las ${state.totalCount} paradas.',
        action: 'Limpiar');
    if (ok == true) {
      HapticFeedback.mediumImpact();
      await state.clearAll();
    }
  }

  Future<void> _confirmDelete(AppState state, Client c) async {
    final ok = await _Confirm.show(context,
        title: 'Eliminar',
        body: '"${c.name}" será eliminado.',
        action: 'Eliminar');
    if (ok == true) {
      HapticFeedback.lightImpact();
      await state.deleteClient(c.id);
    }
  }
}

// ── App bar ───────────────────────────────────────────────────────────────────
class _AppBar extends StatelessWidget {
  final AppState state;
  final VoidCallback onClear;
  const _AppBar({required this.state, required this.onClear});

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      backgroundColor: const Color(0xFF0D1017),
      elevation: 0,
      pinned: true,
      toolbarHeight: 52,
      titleSpacing: 0,
      title: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          // Logo
          RichText(text: TextSpan(children: [
            TextSpan('ROUTE', style: GoogleFonts.barlow(
                color: Colors.white, fontSize: 20,
                fontWeight: FontWeight.w800, letterSpacing: 1)),
            TextSpan('OPT', style: GoogleFonts.barlow(
                color: const Color(0xFF00C896), fontSize: 20,
                fontWeight: FontWeight.w800, letterSpacing: 1)),
          ])),
          const Spacer(),
          // Selector de modo
          _TravelModeSelector(
            current: state.travelMode,
            onChanged: state.setTravelMode,
          ),
          const SizedBox(width: 6),
          // Más opciones
          if (state.clients.isNotEmpty)
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded,
                  color: Color(0xFF3A3E52), size: 20),
              color: const Color(0xFF161A27),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Color(0xFF252A3A))),
              onSelected: (_) => onClear(),
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'clear',
                  child: Row(children: [
                    const Icon(Icons.delete_sweep_outlined,
                        color: Color(0xFFFF4757), size: 16),
                    const SizedBox(width: 8),
                    Text('Limpiar todo', style: GoogleFonts.ibmPlexMono(
                        color: const Color(0xFFFF4757), fontSize: 13)),
                  ]),
                ),
              ],
            ),
        ]),
      ),
    );
  }
}

// ── Header contextual ─────────────────────────────────────────────────────────
class _ContextHeader extends StatelessWidget {
  final AppState state;
  const _ContextHeader({required this.state});

  @override
  Widget build(BuildContext context) {
    if (state.clients.isEmpty) return const SliverToBoxAdapter(child: SizedBox.shrink());

    final total     = state.totalCount;
    final completed = state.completedCount;
    final risk      = state.riskCount;
    final weekday   = _wd(DateTime.now().weekday);
    final hour      = DateTime.now().hour;
    final greet     = hour < 12 ? 'Buenos días' : hour < 19 ? 'Buenas tardes' : 'Buenas noches';

    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 2),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Línea 1: saludo + fecha + resumen
          Row(children: [
            Text('$greet · $weekday  ',
                style: GoogleFonts.ibmPlexMono(
                    color: const Color(0xFF3A3E52), fontSize: 11)),
            Text('$total parada${total != 1 ? 's' : ''}',
                style: GoogleFonts.barlow(
                    color: const Color(0xFF5C6278), fontSize: 13)),
            if (risk > 0) ...[
              Text('  ·  ', style: GoogleFonts.barlow(
                  color: const Color(0xFF3A3E52), fontSize: 13)),
              Text('$risk en riesgo', style: GoogleFonts.barlow(
                  color: const Color(0xFFFFA500),
                  fontSize: 13, fontWeight: FontWeight.w600)),
            ] else if (total > 0) ...[
              Text('  ·  ', style: GoogleFonts.barlow(
                  color: const Color(0xFF3A3E52), fontSize: 13)),
              Text('Ruta OK', style: GoogleFonts.barlow(
                  color: const Color(0xFF00C896),
                  fontSize: 13, fontWeight: FontWeight.w600)),
            ],
          ]),
          const SizedBox(height: 3),
          // Línea 2: progreso
          Row(children: [
            Text(
              '$completed / $total completado${total != 1 ? 's' : ''}',
              style: GoogleFonts.ibmPlexMono(
                  color: completed == total && total > 0
                      ? const Color(0xFF00C896)
                      : const Color(0xFF5C6278),
                  fontSize: 11, fontWeight: FontWeight.w600),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(
                      begin: 0,
                      end: total == 0 ? 0.0 : completed / total),
                  duration: const Duration(milliseconds: 500),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => LinearProgressIndicator(
                    value: v,
                    minHeight: 3,
                    backgroundColor: const Color(0xFF1A1E2C),
                    valueColor: AlwaysStoppedAnimation(
                      v >= 1.0
                          ? const Color(0xFF00C896)
                          : const Color(0xFF58A6FF),
                    ),
                  ),
                ),
              ),
            ),
          ]),
        ]),
      ).animate().fadeIn(duration: 300.ms),
    );
  }

  String _wd(int w) => const {
    1: 'Lunes', 2: 'Martes', 3: 'Miércoles', 4: 'Jueves',
    5: 'Viernes', 6: 'Sábado', 7: 'Domingo',
  }[w]!;
}

// ── Selector modo de viaje ────────────────────────────────────────────────────
class _TravelModeSelector extends StatelessWidget {
  final TravelMode current;
  final ValueChanged<TravelMode> onChanged;
  const _TravelModeSelector({required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF161A27),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF252A3A)),
      ),
      padding: const EdgeInsets.all(3),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: TravelMode.values.map((mode) {
          final active = mode == current;
          return GestureDetector(
            onTap: () {
              if (!active) {
                HapticFeedback.selectionClick();
                onChanged(mode);
              }
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 36, height: 30,
              decoration: BoxDecoration(
                color: active
                    ? const Color(0xFF00C896).withOpacity(0.15)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(7),
                border: active
                    ? Border.all(
                        color: const Color(0xFF00C896).withOpacity(0.4))
                    : null,
              ),
              child: Center(
                child: Text(mode.emoji,
                    style: TextStyle(
                        fontSize: active ? 16 : 14,
                        color: active ? Colors.white : Colors.white38)),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ── Lista ─────────────────────────────────────────────────────────────────────
class _ClientList extends StatelessWidget {
  final List<Client> clients;
  final String? lastAddedId;
  final void Function(int, int) onReorder;
  final void Function(Client) onEdit;
  final void Function(Client) onDelete;
  final void Function(String) onPin;

  const _ClientList({
    required this.clients, required this.lastAddedId,
    required this.onReorder, required this.onEdit,
    required this.onDelete, required this.onPin,
  });

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.only(top: 8, bottom: 120),
      sliver: SliverReorderableList(
        itemCount: clients.length,
        onReorder: onReorder,
        proxyDecorator: (child, index, animation) =>
            AnimatedBuilder(
              animation: animation,
              builder: (_, ch) {
                final t = Curves.easeOut.transform(animation.value);
                return Transform.scale(
                  scale: 1.0 + t * 0.02,
                  child: Material(
                    color: Colors.transparent,
                    elevation: t * 14,
                    shadowColor: const Color(0xFF00C896).withOpacity(0.25),
                    child: ch,
                  ),
                );
              },
              child: child,
            ),
        itemBuilder: (context, index) {
          final c = clients[index];
          final isNew = c.id == lastAddedId;

          Widget card = StopCard(
            client: c,
            index: index,
            onTap: () => onEdit(c),
            onDelete: () => onDelete(c),
            onPin: () => onPin(c.id),
          );

          if (isNew) {
            card = card.animate()
                .fadeIn(duration: 300.ms)
                .slideY(begin: -0.25, end: 0,
                    duration: 350.ms, curve: Curves.easeOutCubic)
                .shimmer(duration: 700.ms, delay: 200.ms,
                    color: const Color(0xFF00C896).withOpacity(0.1));
          } else {
            card = card.animate(key: ValueKey('e_$index'))
                .fadeIn(duration: 180.ms,
                    delay: Duration(milliseconds: (index * 20).clamp(0, 200)));
          }

          return ReorderableDelayedDragStartListener(
            key: ValueKey(c.id),
            index: index,
            enabled: !c.pinned && !c.status.isDone,
            child: card,
          );
        },
      ),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────────────────────
class _EmptySliver extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptySliver({required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return SliverFillRemaining(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 36),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 76, height: 76,
            decoration: BoxDecoration(
              color: const Color(0xFF161A27),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF252A3A)),
            ),
            child: const Icon(Icons.route_rounded,
                color: Color(0xFF252A3A), size: 36),
          ),
          const SizedBox(height: 20),
          Text('Sin paradas', style: GoogleFonts.barlow(
              color: Colors.white, fontSize: 24,
              fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(
            'Agrega clientes manualmente\no abre una ubicación desde WhatsApp',
            textAlign: TextAlign.center,
            style: GoogleFonts.ibmPlexMono(
                color: const Color(0xFF3A3E52), fontSize: 12, height: 1.6),
          ),
          const SizedBox(height: 28),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: BoxDecoration(
              color: const Color(0xFF161A27),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: const Color(0xFF25D366).withOpacity(0.2)),
            ),
            child: Row(children: [
              const Icon(Icons.tips_and_updates_outlined,
                  color: Color(0xFF25D366), size: 15),
              const SizedBox(width: 10),
              Expanded(child: Text(
                'WhatsApp → toca ubicación → elige RouteOpt',
                style: GoogleFonts.ibmPlexMono(
                    color: const Color(0xFF5C6278),
                    fontSize: 11, height: 1.4),
              )),
            ]),
          ),
        ]).animate().fadeIn(duration: 400.ms).slideY(begin: 0.05, end: 0),
      ),
    );
  }
}

// ── FAB ───────────────────────────────────────────────────────────────────────
class _FAB extends StatelessWidget {
  final bool isEmpty;
  final VoidCallback onTap;
  const _FAB({required this.isEmpty, required this.onTap});

  @override
  Widget build(BuildContext context) {
    if (isEmpty) {
      return FloatingActionButton.extended(
        onPressed: onTap,
        backgroundColor: const Color(0xFF00C896),
        foregroundColor: Colors.black,
        elevation: 8,
        icon: const Icon(Icons.add_location_alt_rounded, size: 22),
        label: Text('Nueva parada', style: GoogleFonts.barlow(
            fontWeight: FontWeight.w700, fontSize: 15)),
      );
    }
    return FloatingActionButton(
      onPressed: onTap,
      backgroundColor: const Color(0xFF00C896),
      foregroundColor: Colors.black,
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: const Icon(Icons.add_rounded, size: 30),
    );
  }
}

// ── Barra inferior ────────────────────────────────────────────────────────────
class _BottomBar extends StatelessWidget {
  final AppState state;
  const _BottomBar({required this.state});

  @override
  Widget build(BuildContext context) {
    final total     = state.totalCount;
    final completed = state.completedCount;
    final pending   = state.pendingCount;
    final pct       = total == 0 ? 0.0 : completed / total;

    return Container(
      height: 56,
      decoration: const BoxDecoration(
        color: Color(0xFF0D1017),
        border: Border(top: BorderSide(color: Color(0xFF161A27))),
      ),
      child: Row(children: [
        _BStat(completed, 'HECHOS',   const Color(0xFF00C896)),
        _BDiv(),
        _BStat(pending,   'PENDIENTE', const Color(0xFF5C6278)),
        _BDiv(),
        _BStat(total,     'TOTAL',     const Color(0xFF3A3E52)),
        _BDiv(),
        // Progress
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('PROGRESO', style: GoogleFonts.ibmPlexMono(
                    color: const Color(0xFF3A3E52),
                    fontSize: 8, letterSpacing: 0.8)),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: Text('${(pct * 100).round()}%',
                      key: ValueKey((pct * 100).round()),
                      style: GoogleFonts.ibmPlexMono(
                          color: pct >= 1.0
                              ? const Color(0xFF00C896)
                              : const Color(0xFF5C6278),
                          fontSize: 9, fontWeight: FontWeight.w700)),
                ),
              ]),
              const SizedBox(height: 5),
              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: pct),
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => LinearProgressIndicator(
                    value: v,
                    minHeight: 4,
                    backgroundColor: const Color(0xFF1A1E2C),
                    valueColor: AlwaysStoppedAnimation(
                      v >= 1.0
                          ? const Color(0xFF00C896)
                          : const Color(0xFF58A6FF),
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _BStat extends StatelessWidget {
  final int n;
  final String label;
  final Color color;
  const _BStat(this.n, this.label, this.color);

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 64,
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
        child: Text('$n', key: ValueKey(n),
            style: GoogleFonts.ibmPlexMono(
                color: color, fontSize: 17, fontWeight: FontWeight.w700)),
      ),
      Text(label, style: GoogleFonts.ibmPlexMono(
          color: color.withOpacity(0.45),
          fontSize: 8, letterSpacing: 0.8)),
    ]),
  );
}

class _BDiv extends StatelessWidget {
  @override
  Widget build(_) =>
      Container(width: 1, height: 26, color: const Color(0xFF161A27));
}

// ── Confirm dialog ────────────────────────────────────────────────────────────
class _Confirm extends StatelessWidget {
  final String title, body, action;
  const _Confirm({required this.title, required this.body, required this.action});

  static Future<bool?> show(BuildContext ctx,
      {required String title, required String body, required String action}) =>
      showDialog<bool>(context: ctx,
          builder: (_) => _Confirm(title: title, body: body, action: action));

  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: const Color(0xFF161A27),
    shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Color(0xFF252A3A))),
    title: Text(title, style: GoogleFonts.barlow(
        color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
    content: Text(body, style: GoogleFonts.ibmPlexMono(
        color: const Color(0xFF5C6278), fontSize: 13)),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context, false),
        child: Text('Cancelar', style: GoogleFonts.barlow(
            color: const Color(0xFF5C6278))),
      ),
      ElevatedButton(
        onPressed: () => Navigator.pop(context, true),
        style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF4757),
            foregroundColor: Colors.white, elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8))),
        child: Text(action, style: GoogleFonts.barlow(fontWeight: FontWeight.w700)),
      ),
    ],
  );
}
