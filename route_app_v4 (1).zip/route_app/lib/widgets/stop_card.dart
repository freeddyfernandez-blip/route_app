// lib/widgets/stop_card.dart — v4
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/client.dart';
import '../state/app_state.dart';

class StopCard extends StatelessWidget {
  final Client client;
  final int index;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  final VoidCallback? onPin;
  final bool isDragging;

  const StopCard({
    super.key,
    required this.client,
    required this.index,
    required this.onTap,
    required this.onDelete,
    this.onPin,
    this.isDragging = false,
  });

  // ── Colores por estado ───────────────────────────────────────────────────────
  static const _cPending   = Color(0xFF3A3E52);
  static const _cActive    = Color(0xFF00C896);
  static const _cCompleted = Color(0xFF2A2E3F);
  static const _cRisk      = Color(0xFFFFA500);
  static const _cLate      = Color(0xFFFF4757);

  Color get _statusColor => switch (client.status) {
    StopStatus.active    => _cActive,
    StopStatus.completed => _cCompleted,
    StopStatus.risk      => _cRisk,
    StopStatus.late      => _cLate,
    _                    => _cPending,  // pending + ok
  };

  bool get _isCompleted => client.status.isDone;
  bool get _isActive    => client.status.isActive;

  Color get _priorityColor => switch (client.priority) {
    Priority.high   => const Color(0xFFFF4757),
    Priority.medium => const Color(0xFFFFA500),
    Priority.low    => const Color(0xFF3A3E52),
  };

  @override
  Widget build(BuildContext context) {
    final mode = context.select((AppState s) => s.travelMode);

    return AnimatedOpacity(
      duration: const Duration(milliseconds: 300),
      opacity: _isCompleted ? 0.45 : 1.0,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: EdgeInsets.symmetric(
          horizontal: isDragging ? 10 : 14,
          vertical: isDragging ? 6 : 3,
        ),
        decoration: BoxDecoration(
          color: _isActive
              ? const Color(0xFF1A2430)
              : _isCompleted
                  ? const Color(0xFF111419)
                  : isDragging
                      ? const Color(0xFF1E2235)
                      : const Color(0xFF161A27),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _isActive
                ? _cActive.withOpacity(0.5)
                : isDragging
                    ? _statusColor.withOpacity(0.5)
                    : const Color(0xFF1E2235),
            width: _isActive || isDragging ? 1.5 : 1,
          ),
          boxShadow: _isActive
              ? [BoxShadow(
                  color: _cActive.withOpacity(0.12),
                  blurRadius: 12, spreadRadius: 0)]
              : isDragging
                  ? [
                      BoxShadow(color: Colors.black.withOpacity(0.4),
                          blurRadius: 16, offset: const Offset(0, 6)),
                    ]
                  : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: _isCompleted ? null : onTap,
            borderRadius: BorderRadius.circular(12),
            splashColor: _statusColor.withOpacity(0.06),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // ── Badge de orden ──────────────────────────────────────────
                  _OrderBadge(
                    index: index,
                    color: _statusColor,
                    isCompleted: _isCompleted,
                    isActive: _isActive,
                  ),
                  const SizedBox(width: 12),

                  // ── Contenido ───────────────────────────────────────────────
                  Expanded(
                    child: _Content(
                      client: client,
                      statusColor: _statusColor,
                      priorityColor: _priorityColor,
                      isCompleted: _isCompleted,
                    ),
                  ),
                  const SizedBox(width: 8),

                  // ── Botones de acción ───────────────────────────────────────
                  if (!_isCompleted)
                    _Actions(
                      client: client,
                      mode: mode,
                      statusColor: _statusColor,
                      isActive: _isActive,
                      onDelete: onDelete,
                    )
                  else
                    // Completed: solo check, sin botones
                    const Icon(Icons.check_circle_rounded,
                        color: Color(0xFF2A2E3F), size: 20),

                  // ── Drag handle ─────────────────────────────────────────────
                  if (!client.pinned && !_isCompleted)
                    Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: Icon(
                        Icons.drag_indicator_rounded,
                        color: isDragging
                            ? _statusColor.withOpacity(0.4)
                            : const Color(0xFF252A3A),
                        size: 16,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Badge de orden ─────────────────────────────────────────────────────────────
class _OrderBadge extends StatelessWidget {
  final int index;
  final Color color;
  final bool isCompleted, isActive;
  const _OrderBadge({
    required this.index, required this.color,
    required this.isCompleted, required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    if (isCompleted) {
      return Container(
        width: 30, height: 30,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF1E2235),
          border: Border.all(color: const Color(0xFF2A2E3F)),
        ),
        child: const Icon(Icons.check_rounded, size: 14, color: Color(0xFF3A3E52)),
      );
    }
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: 30, height: 30,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isActive ? color.withOpacity(0.18) : color.withOpacity(0.08),
        border: Border.all(
          color: isActive ? color.withOpacity(0.7) : color.withOpacity(0.25),
          width: isActive ? 1.5 : 1,
        ),
      ),
      child: Center(
        child: Text(
          '${index + 1}',
          style: GoogleFonts.ibmPlexMono(
            color: color,
            fontSize: index < 9 ? 13 : 11,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}

// ── Contenido de la tarjeta ───────────────────────────────────────────────────
class _Content extends StatelessWidget {
  final Client client;
  final Color statusColor, priorityColor;
  final bool isCompleted;
  const _Content({
    required this.client, required this.statusColor,
    required this.priorityColor, required this.isCompleted,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Nombre + prioridad
        Row(children: [
          if (client.pinned) ...[
            const Icon(Icons.push_pin_rounded,
                color: Color(0xFFFFA500), size: 11),
            const SizedBox(width: 3),
          ],
          Expanded(
            child: Text(
              client.name,
              style: GoogleFonts.barlow(
                color: isCompleted ? const Color(0xFF3A3E52) : Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
                decoration: isCompleted ? TextDecoration.lineThrough : null,
                decorationColor: const Color(0xFF3A3E52),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 4),
          _PriBadge(label: client.priorityLabel, color: priorityColor),
        ]),
        const SizedBox(height: 4),

        // Datos secundarios
        Row(children: [
          // Dot de estado
          Container(
            width: 5, height: 5,
            decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),

          // ETA o coords
          if (client.eta != null)
            Text('ETA ${client.eta}',
                style: GoogleFonts.ibmPlexMono(
                    color: statusColor, fontSize: 10, fontWeight: FontWeight.w600))
          else
            Text(
              '${client.lat.toStringAsFixed(4)}, ${client.lng.toStringAsFixed(4)}',
              style: GoogleFonts.ibmPlexMono(
                  color: const Color(0xFF3A3E52), fontSize: 10),
            ),

          const SizedBox(width: 8),
          Row(children: [
            const Icon(Icons.schedule_rounded, size: 10, color: Color(0xFF3A3E52)),
            const SizedBox(width: 2),
            Text('${client.serviceMinutes}m',
                style: GoogleFonts.ibmPlexMono(
                    color: const Color(0xFF3A3E52), fontSize: 10)),
          ]),

          if (client.windowStart != null) ...[
            const SizedBox(width: 8),
            Text('${client.windowStart}–${client.windowEnd}',
                style: GoogleFonts.ibmPlexMono(
                    color: const Color(0xFF3A3E52), fontSize: 10)),
          ],
        ]),

        // Warning
        if (client.warning != null) ...[
          const SizedBox(height: 3),
          Row(children: [
            const Icon(Icons.warning_amber_rounded,
                size: 10, color: Color(0xFFFF4757)),
            const SizedBox(width: 3),
            Expanded(
              child: Text(client.warning!,
                  style: GoogleFonts.ibmPlexMono(
                      color: const Color(0xFFFF4757), fontSize: 10),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
          ]),
        ],
      ],
    );
  }
}

// ── Botones de acción ─────────────────────────────────────────────────────────
class _Actions extends StatelessWidget {
  final Client client;
  final TravelMode mode;
  final Color statusColor;
  final bool isActive;
  final VoidCallback onDelete;

  const _Actions({
    required this.client, required this.mode, required this.statusColor,
    required this.isActive, required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      // ── Navegar ─────────────────────────────────────────────────────────────
      _ActionBtn(
        tooltip: 'Navegar',
        color: statusColor,
        child: Text(mode.emoji, style: const TextStyle(fontSize: 14)),
        onTap: () => _navigate(client, mode),
      ),
      const SizedBox(width: 6),

      // ── Completar ───────────────────────────────────────────────────────────
      _ActionBtn(
        tooltip: 'Completar',
        color: const Color(0xFF00C896),
        child: const Icon(Icons.check_rounded, size: 16, color: Color(0xFF00C896)),
        onTap: () {
          HapticFeedback.mediumImpact();
          context.read<AppState>().completeClient(client.id);
        },
      ),
      const SizedBox(width: 4),

      // ── Eliminar ─────────────────────────────────────────────────────────────
      GestureDetector(
        onTap: onDelete,
        child: const Padding(
          padding: EdgeInsets.all(4),
          child: Icon(Icons.close_rounded, color: Color(0xFF2A2E3F), size: 15),
        ),
      ),
    ]);
  }

  Future<void> _navigate(Client c, TravelMode m) async {
    final native = Uri.parse(
        'google.navigation:q=${c.lat},${c.lng}&mode=${m.gmapsMode}');
    if (await canLaunchUrl(native)) { await launchUrl(native); return; }
    final web = Uri.parse(
        'https://www.google.com/maps/dir/?api=1'
        '&destination=${c.lat},${c.lng}'
        '&travelmode=${m == TravelMode.walk ? 'walking' : 'driving'}');
    await launchUrl(web, mode: LaunchMode.externalApplication);
  }
}

// ── Botón de acción genérico ──────────────────────────────────────────────────
class _ActionBtn extends StatelessWidget {
  final String tooltip;
  final Color color;
  final Widget child;
  final VoidCallback onTap;
  const _ActionBtn({required this.tooltip, required this.color,
      required this.child, required this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
    message: tooltip,
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        width: 34, height: 34,
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Center(child: child),
      ),
    ),
  );
}

// ── Badge de prioridad ────────────────────────────────────────────────────────
class _PriBadge extends StatelessWidget {
  final String label;
  final Color color;
  const _PriBadge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
    decoration: BoxDecoration(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(4),
      border: Border.all(color: color.withOpacity(0.2), width: 0.8),
    ),
    child: Text(label,
        style: GoogleFonts.ibmPlexMono(
            color: color.withOpacity(0.8),
            fontSize: 8, fontWeight: FontWeight.w700, letterSpacing: 0.4)),
  );
}
